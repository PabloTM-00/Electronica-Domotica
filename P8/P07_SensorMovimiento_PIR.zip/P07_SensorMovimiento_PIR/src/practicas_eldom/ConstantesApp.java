package practicas_eldom;

import CommTransport.Comm.tCommConnector;

public class ConstantesApp 
{
	//IniFiles Params
	
	public static final String 			WINDOW_TITLE = "PRÁCTICAS ELECTRÓNICA PARA DOMÓTICA - INTERFACE JAVA "; 
	public static final String 			STATUSBAR_MSGLEFT = "Puerto seleccionado para comunicación ModBus : ";
	public static final String 			CONSOLE_TITLE = "Mostrar mensajes Puerto Serie y Aplicación";
	
	public static final tCommConnector	SERIALCONNECTION = tCommConnector.CN_JSSC;  //tCommConnector.CN_RXTX; //
	
	public static final int				MS_REGULAR_CALL	= 100;
}